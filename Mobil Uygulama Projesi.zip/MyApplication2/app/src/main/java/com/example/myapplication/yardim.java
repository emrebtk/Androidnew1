package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ExpandableListView;

public class yardim extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yardim);
        ExpandableListView listeler2= (ExpandableListView)findViewById(R.id.lstlr2);
        listeler2.setAdapter(new list2(this));
    }
}