package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText kullanici;
    EditText sifre;
    String name= "emrebitik";
    String pass= "1234";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //textboxlardan geleni degişkenlere atadık.
        kullanici = findViewById(R.id.isim);
        sifre = findViewById(R.id.sifre);
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //kullanıcı adı ve şifreyi kontrol ediyoruz
                if(kullanici.getText().toString().equals(name) && sifre.getText().toString().equals(pass))
                {
                    //bilgiler dogru ise belirtilen sayfaya geçer.

                    Intent intent = new Intent(MainActivity.this, menu.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(MainActivity.this, "Kullanıcı Adı ve/veya Şifre Hatalı", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }
}