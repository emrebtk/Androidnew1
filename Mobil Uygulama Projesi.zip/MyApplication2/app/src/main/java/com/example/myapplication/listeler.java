package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.net.MalformedURLException;
import java.net.URL;

public class listeler extends BaseExpandableListAdapter {
    String[] liste={">Sıcak Başlangıç",">Ara Sıcaklar",">Çorbalar",">Ana Yemekler",">Tatlılar",">Atıştırmalıklar",">İçecekler"};
    String[][] listeici={{"Alinazik yemegi(250gr 143 kalori)","İçli köfte(1 tane 120 kalori)","Fırında mantar(100gr 82 kalori)"},{"Patatesli Sigara Böreği(1 adet 80 kalori)","Bamya Kızartması(100gr 72 kalori)","Kabak Kızartması(100gr 226 kalori)"},
            {"Mercimek çorbası(100gr 56 kalori)","Mantar Çorbası(100gr 35 kalori)","Domates Çorbası(100gr 30 kalori)","Kremalı Tavuk Çorbası(100gr 48 kalori)"},{"Lahmacun(1adet 320 kalori)","Adana Kebab(150gr 360kalori)","Beyti Kebab(100gr 250kalori)"},
            {"künefe(100gr 253 kalori)","Baklava(100gr 320 kalori)","Cheesecake(100gr 320 kalori)"},{"Patates Kızartması(100gr 320 kalori)","Soğan Halkası(100gr 400 kalori)"},{"Soda(200ml 0 kalori)","Su(200ml 0 kalori)","Kola(200ml 80 kalori)","Portakal Suyu(200ml 120 kalori)"}};
    private Context c;
    public listeler(Context c){
        this.c = c;
    }


    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public int getGroupCount() {
        return liste.length;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return listeici[groupPosition].length;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return null;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return null;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        Intent link = new Intent(Intent.ACTION_VIEW);
        link.setData(Uri.parse("google.com"));

        return 0;
    }


    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        TextView tv1 = new TextView(c);
        tv1.setText(liste[groupPosition]);
        tv1.setTextSize(20);
        tv1.setPadding( 40,  10 , 10,  10);
        tv1.setTextColor(Color.BLACK);
        return tv1;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        TextView tv2 =new TextView(c);
        tv2.setText( listeici[groupPosition][childPosition] );
        tv2.setTextSize(16);
        tv2.setPadding( 40,  10 , 10,  10);
        tv2.setTextColor(Color.BLUE);



        return tv2;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {


        return true;
    }

}
