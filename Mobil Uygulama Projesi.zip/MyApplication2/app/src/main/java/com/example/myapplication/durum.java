package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class durum extends AppCompatActivity {
    private EditText editText,yas;
    private TextView boy_tv,durum_tv,ideal_tv,kilo_tv,kalori_tv;
    private SeekBar seekBar;
    private RadioGroup radioGroup;
    private boolean erkekmi = true;
    private double boy = 0.0;
    private int kilo=50;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_durum);

        editText = (EditText) findViewById(R.id.editText2);
        boy_tv = (TextView) findViewById(R.id.boy_tv);
        durum_tv = (TextView) findViewById(R.id.durum_tv);

        kilo_tv = (TextView) findViewById(R.id.kilo_tv);
        ideal_tv = (TextView) findViewById(R.id.ideal_tv);


        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        seekBar =  (SeekBar) findViewById(R.id.seekBar);

        editText.addTextChangedListener(editTextOlayIsleyicisi);
        seekBar.setOnSeekBarChangeListener(seekBarOlayIsleyicisi);
        radioGroup.setOnCheckedChangeListener(radioGroupOlayIsleyicisi);

    }

    private TextWatcher editTextOlayIsleyicisi = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            try {
                int b=Integer.parseInt(s.toString());
                boy = Double.parseDouble(s.toString())/100.0;
            }catch (NumberFormatException e){
                boy = 0.0;

            }
            Guncelle();
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };
    private SeekBar.OnSeekBarChangeListener seekBarOlayIsleyicisi = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            kilo = 30+progress;
            Guncelle();
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };
    private RadioGroup.OnCheckedChangeListener radioGroupOlayIsleyicisi = new RadioGroup.OnCheckedChangeListener() {

        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId==R.id.bay){
                erkekmi = true;
            }
            else if (checkedId==R.id.bayan){
                erkekmi = false;
            }
            Guncelle();
        }
    };

    private  void  Guncelle(){
        yas=(EditText) findViewById(R.id.yas_et);
        kalori_tv=(TextView) findViewById(R.id.kalori_tv);
        kilo_tv.setText(String.valueOf(kilo)+" kg");
        boy_tv.setText(String.valueOf(boy)+ " mt");

            int y = Integer.parseInt(yas.getText().toString());






        if (boy>0.99){

            int ideal_kiloBay = (int) (50+2.3*((boy*100*0.4)-60));
            int ideal_kiloBayan = (int) (45.5+2.3*((boy*100*0.4)-60));

            double vki = kilo/(boy*boy);



            if(vki < 18.5){
                durum_tv.setBackgroundResource(R.color.durum_zayif);
                durum_tv.setText(R.string.zayif);
            }else if(vki>=18.5 && vki<= 24.9){
                durum_tv.setBackgroundResource(R.color.durum_ideal);
                durum_tv.setText(R.string.ideal);
            }else if(vki>=25 && vki<= 29.9){
                durum_tv.setBackgroundResource(R.color.durum_fazlakilolu);
                durum_tv.setText(R.string.fazlakilolu);
            }else if(vki>=30 && vki<= 34.9){
                durum_tv.setBackgroundResource(R.color.durum_obez);
                durum_tv.setText(R.string.obez1);
            }else if(vki>=35 && vki<= 39.9){
                durum_tv.setBackgroundResource(R.color.durum_obez);
                durum_tv.setText(R.string.obez2);
            }else if(vki >= 40){
                durum_tv.setBackgroundResource(R.color.durum_obez);
                durum_tv.setText(R.string.obez3);
            }


            if (erkekmi){
                //bay ise
                ideal_tv.setText(String.valueOf(ideal_kiloBay));
                double k=(66+(13.75*kilo)+(5*boy*100)-(6.8*y))/1.0;
                kalori_tv.setText("  "+k);

            }
            else{
                //bayan ise
                ideal_tv.setText(String.valueOf(ideal_kiloBayan));
                double k=(665+(9.6*kilo)+(1.7*boy*100)-(4.7*y))/1.00;
                kalori_tv.setText("  "+k);
            }



        }
        else{
            ideal_tv.setText(" ");
            durum_tv.setText(" ");

        }
    }
    }
