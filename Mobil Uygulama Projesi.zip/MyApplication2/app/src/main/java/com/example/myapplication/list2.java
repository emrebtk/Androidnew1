package com.example.myapplication;

import android.content.Context;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;

public class list2 extends BaseExpandableListAdapter {
    String[] liste2={"Durum Bilgisi Kısmı Hakkında ","Yiyecek/İçecek kısmı Hakkında ","Hatalar İçin Geribildirim"};
    String[][] listeici2={{"Bu kısımda kullanıcı önce yaş bilgisi girmeli boy ,kilove cinsiyet kısmını işaretledikten sonra kenisine otomatik olarak gerekli bilgileri verilir"},{"Bu kısımda yiyecek iceceklerin miktara göre kalori bilgisi  verilmektedir"},{"Var olan hatalar için 'emrebtk@gmail.com' mail adresinden dönüş yapabilirsiniz"}};
    private Context c2;
    public list2(Context c2){
        this.c2 = c2;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public int getGroupCount() {
        return liste2.length;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return listeici2[groupPosition].length;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return null;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return null;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return 0;
    }


    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        TextView tv1 = new TextView(c2);
        tv1.setText(liste2[groupPosition]);
        tv1.setTextSize(20);
        tv1.setPadding( 40,  10 , 10,  10);
        tv1.setTextColor(Color.BLACK);
        return tv1;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        TextView tv2 =new TextView(c2);
        tv2.setText( listeici2[groupPosition][childPosition] );
        tv2.setTextSize(16);
        tv2.setPadding( 40,  10 , 10,  10);
        tv2.setTextColor(Color.BLUE);
        return tv2;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
